# Run the project
1. put final_project.py in the same dir with test.csv and train.csv
2. python final_project.py